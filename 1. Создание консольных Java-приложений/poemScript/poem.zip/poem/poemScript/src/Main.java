import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Main {

    public static void main(String[] args) {
        String [] roles= {
                "Городничий","Аммос Федорович",
                "Артемий Филиппович",
                "Лука Лукич"};
        String [] textLines={
                "Городничий: Я пригласил вас, господа, с тем, чтобы сообщить вам пренеприятное известие: к нам едет ревизор.",
                "Аммос Федорович: Как ревизор?",
                "Артемий Филиппович: Как ревизор?",
                "Городничий: Ревизор из Петербурга, инкогнито. И еще с секретным предписаньем.",
                "Аммос Федорович: Вот те на!",
                "Артемий Филиппович: Вот не было заботы, так подай!",
                "Лука Лукич: Господи боже! еще и с секретным предписаньем!"};

        System.out.println(printTextPerRole(roles, textLines));

    }

    public static String printTextPerRole(String[] roles, String[] textLines) {
        Map<String, List<String>> script = new HashMap<>();

        for (int i = 0; i < textLines.length; i++) {
            String line = textLines[i];
            int index = line.indexOf(':');
            String role = line.substring(0, index);
            String text = line.substring(index + 1);

            if (script.containsKey(role)) {
                script.get(role).add((i + 1) + ")" + text);
            } else {
                List<String> lines = new ArrayList<>();
                lines.add((i + 1) + ")" + text);
                script.put(role, lines);
            }
        }

        for (String character : roles) {
            if (!script.containsKey(character)) {
                script.put(character, new ArrayList<>());
            }
        }

        StringBuilder result = new StringBuilder();

        for (int i = 0; i < roles.length; i++) {
            String role = roles[i];
            result.append(role).append(":\n");
            List<String> values = script.get(role);

            for (String value : values) {
                result.append(value).append("\n");
            }

            if (i < roles.length-1) {
                result.append("\n");
            }
        }

        return result.toString();
    }
}